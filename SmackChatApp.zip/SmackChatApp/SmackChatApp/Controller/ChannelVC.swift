//
//  ChannelVC.swift
//  SmackChatApp
//
//  Created by mac on 27/03/20.
//  Copyright © 2020 KuldeepBhandari. All rights reserved.
//

import UIKit

class ChannelVC: UIViewController {
    
    @IBOutlet weak var loginOutlets: UIButton!
    
    @IBOutlet weak var userImage: CircleImage!
    
    @IBOutlet weak var tableView: UITableView!
    @IBAction func prepareForUnwindSegue(segue:UIStoryboardSegue){}
    override func viewDidLoad() {
        super.viewDidLoad()
        self.revealViewController()?.rearViewRevealWidth = self.view.frame.size.width-60
        //        MARK:To listen notification center
        NotificationCenter.default.addObserver(self, selector: #selector(saveUserLoginData(_:)), name: NOTIF_USER_DATA_DID_CHANGE, object: nil)
        tableView.delegate = self
        tableView.dataSource = self
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setUpUserInfo()
    }
    @objc func saveUserLoginData(_ notification:Notification){
        setUpUserInfo()
    }
    
    //    MARK:To save the data if we minimize the application from background
    func setUpUserInfo(){
        if AuthService.instance.isLoggedIn{
            userImage.image = UIImage(named: UserDataServices.instance.avatarName)
            loginOutlets.setTitle(UserDataServices.instance.name, for: .normal)
            userImage.backgroundColor = UserDataServices.instance.returnColor(component: UserDataServices.instance.avatarColor)
        }else{
            userImage.image = UIImage(named: "menuProfileIcon")
            loginOutlets.setTitle("Login", for: .normal)
            userImage.backgroundColor = UIColor.clear
        }
    }
    @IBAction func tappedOnAddChannel(_ sender: UIButton) {
        
    }
    
    @IBAction func tappedOnLogin(_ sender: UIButton) {
        if AuthService.instance.isLoggedIn{
            let profileVc = ProfileVC()
            profileVc.modalPresentationStyle = .custom
            present(profileVc, animated: true, completion: nil)
        }else{
            performSegue(withIdentifier: TO_LOGIN, sender: nil)
        }
    }
}


//MARK:Tableview datasource and delegate

extension ChannelVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MessageService.instance.channels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ChannelCell", for: indexPath) as? ChannelCell{
            let channel = MessageService.instance.channels[indexPath.row]
            cell.configureCell(channel: channel)
            return cell
            
        }else{
            return UITableViewCell()
        }
    }
    
    
}
